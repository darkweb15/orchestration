"use client"

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { TrendingUp, TrendingDown, Activity, Users, Globe, Database, Zap, Clock } from "lucide-react"
import { cn } from "@/lib/utils"

const monthlyData = [
  { month: "Jan", scraped: 4500, success: 4200, failed: 300 },
  { month: "Feb", scraped: 5200, success: 4900, failed: 300 },
  { month: "Mar", scraped: 6100, success: 5800, failed: 300 },
  { month: "Apr", scraped: 5800, success: 5400, failed: 400 },
  { month: "May", scraped: 7200, success: 6800, failed: 400 },
  { month: "Jun", scraped: 8500, success: 8100, failed: 400 },
  { month: "Jul", scraped: 7800, success: 7400, failed: 400 },
  { month: "Aug", scraped: 9200, success: 8700, failed: 500 },
  { month: "Sep", scraped: 8900, success: 8400, failed: 500 },
  { month: "Oct", scraped: 10500, success: 10000, failed: 500 },
  { month: "Nov", scraped: 11200, success: 10700, failed: 500 },
  { month: "Dec", scraped: 12500, success: 12000, failed: 500 },
]

const hourlyData = [
  { hour: "00:00", requests: 120 },
  { hour: "02:00", requests: 80 },
  { hour: "04:00", requests: 60 },
  { hour: "06:00", requests: 90 },
  { hour: "08:00", requests: 280 },
  { hour: "10:00", requests: 450 },
  { hour: "12:00", requests: 380 },
  { hour: "14:00", requests: 520 },
  { hour: "16:00", requests: 480 },
  { hour: "18:00", requests: 350 },
  { hour: "20:00", requests: 290 },
  { hour: "22:00", requests: 180 },
]

const sourceData = [
  { name: "E-commerce", value: 35 },
  { name: "Social", value: 25 },
  { name: "News", value: 20 },
  { name: "APIs", value: 15 },
  { name: "Other", value: 5 },
]

const performanceData = [
  { subject: "Speed", A: 85, fullMark: 100 },
  { subject: "Reliability", A: 92, fullMark: 100 },
  { subject: "Coverage", A: 78, fullMark: 100 },
  { subject: "Accuracy", A: 95, fullMark: 100 },
  { subject: "Efficiency", A: 88, fullMark: 100 },
  { subject: "Uptime", A: 99, fullMark: 100 },
]

const COLORS = [
  "oklch(0.7 0.2 230)",
  "oklch(0.7 0.18 165)",
  "oklch(0.8 0.15 195)",
  "oklch(0.55 0.15 280)",
  "oklch(0.75 0.15 85)",
]

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="rounded-xl border border-border bg-card/95 backdrop-blur-sm p-3 shadow-xl">
        <p className="text-sm font-medium text-foreground mb-2">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} className="text-xs" style={{ color: entry.color }}>
            {entry.name}: {entry.value.toLocaleString()}
          </p>
        ))}
      </div>
    )
  }
  return null
}

function StatBox({
  title,
  value,
  change,
  changeType,
  icon: Icon,
}: {
  title: string
  value: string
  change: string
  changeType: "up" | "down" | "neutral"
  icon: React.ElementType
}) {
  return (
    <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5 transition-all hover:shadow-lg hover:shadow-neon-blue/5">
      <div className="flex items-center justify-between mb-4">
        <div className="rounded-xl bg-neon-blue/10 p-3">
          <Icon className="h-5 w-5 text-neon-blue" />
        </div>
        <div className={cn(
          "flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full",
          changeType === "up" && "bg-neon-green/10 text-neon-green",
          changeType === "down" && "bg-destructive/10 text-destructive",
          changeType === "neutral" && "bg-muted text-muted-foreground"
        )}>
          {changeType === "up" && <TrendingUp className="h-3 w-3" />}
          {changeType === "down" && <TrendingDown className="h-3 w-3" />}
          {change}
        </div>
      </div>
      <p className="text-sm text-muted-foreground mb-1">{title}</p>
      <p className="text-2xl font-bold text-foreground">{value}</p>
    </div>
  )
}

export default function StatisticsPage() {
  return (
    <DashboardLayout title="Statistics">
      <div className="p-6 space-y-6">
        {/* Stats Overview */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatBox
            title="Total Requests"
            value="1.2M"
            change="+15.3%"
            changeType="up"
            icon={Activity}
          />
          <StatBox
            title="Active Sources"
            value="847"
            change="+8.2%"
            changeType="up"
            icon={Globe}
          />
          <StatBox
            title="Data Collected"
            value="48.2 TB"
            change="+22.1%"
            changeType="up"
            icon={Database}
          />
          <StatBox
            title="Avg Response"
            value="1.2s"
            change="-12%"
            changeType="up"
            icon={Zap}
          />
        </div>

        {/* Main Charts Row */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Monthly Overview */}
          <div className="lg:col-span-2 rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground">Monthly Overview</h3>
                <p className="text-sm text-muted-foreground">Scraping activity by month</p>
              </div>
              <div className="flex gap-4 text-xs">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-neon-blue" />
                  <span className="text-muted-foreground">Total</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-neon-green" />
                  <span className="text-muted-foreground">Success</span>
                </div>
              </div>
            </div>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.02 250)" vertical={false} />
                  <XAxis dataKey="month" tick={{ fill: "oklch(0.65 0.02 250)", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "oklch(0.65 0.02 250)", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="scraped" fill="oklch(0.7 0.2 230)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="success" fill="oklch(0.7 0.18 165)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Performance Radar */}
          <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5">
            <h3 className="text-lg font-semibold text-foreground mb-2">Performance Score</h3>
            <p className="text-sm text-muted-foreground mb-4">Overall system metrics</p>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={performanceData}>
                  <PolarGrid stroke="oklch(0.25 0.02 250)" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: "oklch(0.65 0.02 250)", fontSize: 11 }} />
                  <PolarRadiusAxis tick={false} axisLine={false} />
                  <Radar
                    name="Score"
                    dataKey="A"
                    stroke="oklch(0.8 0.15 195)"
                    fill="oklch(0.8 0.15 195)"
                    fillOpacity={0.3}
                    strokeWidth={2}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Second Charts Row */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Hourly Activity */}
          <div className="lg:col-span-2 rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5">
            <h3 className="text-lg font-semibold text-foreground mb-2">Hourly Activity</h3>
            <p className="text-sm text-muted-foreground mb-4">Requests throughout the day</p>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={hourlyData}>
                  <defs>
                    <linearGradient id="colorRequests" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.7 0.2 230)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="oklch(0.7 0.2 230)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.02 250)" vertical={false} />
                  <XAxis dataKey="hour" tick={{ fill: "oklch(0.65 0.02 250)", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "oklch(0.65 0.02 250)", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="requests"
                    stroke="oklch(0.7 0.2 230)"
                    fill="url(#colorRequests)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Source Distribution */}
          <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5">
            <h3 className="text-lg font-semibold text-foreground mb-2">Source Distribution</h3>
            <p className="text-sm text-muted-foreground mb-4">Data by category</p>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={sourceData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {sourceData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-2 mt-4">
              {sourceData.map((item, index) => (
                <div key={item.name} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: COLORS[index] }} />
                    <span className="text-muted-foreground">{item.name}</span>
                  </div>
                  <span className="font-semibold text-foreground">{item.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Stats */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatBox
            title="Success Rate"
            value="94.8%"
            change="+2.3%"
            changeType="up"
            icon={TrendingUp}
          />
          <StatBox
            title="Active Jobs"
            value="127"
            change="+18"
            changeType="up"
            icon={Clock}
          />
          <StatBox
            title="Users Online"
            value="2,847"
            change="+156"
            changeType="up"
            icon={Users}
          />
          <StatBox
            title="Error Rate"
            value="0.8%"
            change="-0.3%"
            changeType="up"
            icon={Activity}
          />
        </div>
      </div>
    </DashboardLayout>
  )
}
