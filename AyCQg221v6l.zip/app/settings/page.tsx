"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import {
  User,
  Bell,
  Shield,
  Globe,
  Database,
  Zap,
  Key,
  Palette,
  HardDrive,
  Webhook,
  CreditCard,
  AlertTriangle,
  ChevronRight,
  Moon,
  Sun,
  Monitor,
} from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

const settingsSections = [
  { id: "account", icon: User, label: "Account" },
  { id: "notifications", icon: Bell, label: "Notifications" },
  { id: "security", icon: Shield, label: "Security" },
  { id: "proxy", icon: Globe, label: "Proxy Settings" },
  { id: "storage", icon: Database, label: "Data Storage" },
  { id: "performance", icon: Zap, label: "Performance" },
  { id: "api", icon: Key, label: "API Keys" },
  { id: "appearance", icon: Palette, label: "Appearance" },
  { id: "webhooks", icon: Webhook, label: "Webhooks" },
  { id: "billing", icon: CreditCard, label: "Billing" },
  { id: "danger", icon: AlertTriangle, label: "Danger Zone" },
]

export default function SettingsPage() {
  const [activeSection, setActiveSection] = useState("account")
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    jobComplete: true,
    jobFailed: true,
    weeklyReport: false,
    marketing: false,
  })
  const [theme, setTheme] = useState("dark")

  return (
    <DashboardLayout title="Settings">
      <div className="flex h-full">
        {/* Settings Sidebar */}
        <div className="w-64 border-r border-border bg-card/30 p-4 hidden lg:block">
          <nav className="space-y-1">
            {settingsSections.map((section) => (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all",
                  activeSection === section.id
                    ? "bg-gradient-to-r from-neon-blue/20 to-transparent text-neon-cyan border-l-2 border-neon-cyan"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
              >
                <section.icon className="h-4 w-4" />
                {section.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Settings Content */}
        <div className="flex-1 p-6 overflow-y-auto">
          {/* Account Settings */}
          {activeSection === "account" && (
            <div className="max-w-2xl space-y-6">
              <div>
                <h2 className="text-xl font-bold text-foreground mb-1">Account Settings</h2>
                <p className="text-sm text-muted-foreground">Manage your account information</p>
              </div>

              <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5 space-y-5">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Display Name</label>
                  <Input defaultValue="ScraperPro User" className="bg-muted/30 border-border/50 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Email Address</label>
                  <Input defaultValue="pro@scraperpro.com" className="bg-muted/30 border-border/50 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Company Name</label>
                  <Input defaultValue="ScraperPro Inc." className="bg-muted/30 border-border/50 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Timezone</label>
                  <select className="w-full bg-muted/30 border border-border/50 rounded-xl px-3 py-2 text-sm text-foreground">
                    <option>America/Los_Angeles (PST)</option>
                    <option>America/New_York (EST)</option>
                    <option>Europe/London (GMT)</option>
                    <option>Asia/Tokyo (JST)</option>
                  </select>
                </div>
                <button className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-neon-blue to-neon-cyan text-background font-medium hover:opacity-90 transition-all">
                  Save Changes
                </button>
              </div>
            </div>
          )}

          {/* Notifications Settings */}
          {activeSection === "notifications" && (
            <div className="max-w-2xl space-y-6">
              <div>
                <h2 className="text-xl font-bold text-foreground mb-1">Notifications</h2>
                <p className="text-sm text-muted-foreground">Configure how you receive notifications</p>
              </div>

              <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5 space-y-4">
                {[
                  { key: "email", label: "Email Notifications", desc: "Receive notifications via email" },
                  { key: "push", label: "Push Notifications", desc: "Browser push notifications" },
                  { key: "jobComplete", label: "Job Completed", desc: "Notify when scraping jobs complete" },
                  { key: "jobFailed", label: "Job Failed", desc: "Notify when jobs fail" },
                  { key: "weeklyReport", label: "Weekly Reports", desc: "Receive weekly activity summary" },
                  { key: "marketing", label: "Marketing Emails", desc: "Product updates and tips" },
                ].map((item) => (
                  <div key={item.key} className="flex items-center justify-between py-2">
                    <div>
                      <p className="text-sm font-medium text-foreground">{item.label}</p>
                      <p className="text-xs text-muted-foreground">{item.desc}</p>
                    </div>
                    <Switch
                      checked={notifications[item.key as keyof typeof notifications]}
                      onCheckedChange={(checked) =>
                        setNotifications((prev) => ({ ...prev, [item.key]: checked }))
                      }
                      className="data-[state=checked]:bg-neon-green"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Security Settings */}
          {activeSection === "security" && (
            <div className="max-w-2xl space-y-6">
              <div>
                <h2 className="text-xl font-bold text-foreground mb-1">Security</h2>
                <p className="text-sm text-muted-foreground">Protect your account</p>
              </div>

              <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5 space-y-5">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Current Password</label>
                  <Input type="password" placeholder="Enter current password" className="bg-muted/30 border-border/50 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">New Password</label>
                  <Input type="password" placeholder="Enter new password" className="bg-muted/30 border-border/50 rounded-xl" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Confirm Password</label>
                  <Input type="password" placeholder="Confirm new password" className="bg-muted/30 border-border/50 rounded-xl" />
                </div>
                <button className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-neon-blue to-neon-cyan text-background font-medium hover:opacity-90 transition-all">
                  Update Password
                </button>
              </div>

              <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-foreground">Two-Factor Authentication</p>
                    <p className="text-xs text-muted-foreground">Add an extra layer of security</p>
                  </div>
                  <button className="px-4 py-2 rounded-xl bg-neon-green/10 text-neon-green font-medium hover:bg-neon-green/20 transition-all text-sm">
                    Enable 2FA
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Proxy Settings */}
          {activeSection === "proxy" && (
            <div className="max-w-2xl space-y-6">
              <div>
                <h2 className="text-xl font-bold text-foreground mb-1">Proxy Settings</h2>
                <p className="text-sm text-muted-foreground">Configure your proxy rotation</p>
              </div>

              <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5 space-y-4">
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-foreground">Auto-Rotate Proxies</p>
                    <p className="text-xs text-muted-foreground">Automatically rotate between proxies</p>
                  </div>
                  <Switch defaultChecked className="data-[state=checked]:bg-neon-green" />
                </div>
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-foreground">Residential Proxies</p>
                    <p className="text-xs text-muted-foreground">Use residential IP addresses</p>
                  </div>
                  <Switch defaultChecked className="data-[state=checked]:bg-neon-green" />
                </div>
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-foreground">Datacenter Proxies</p>
                    <p className="text-xs text-muted-foreground">Use datacenter IP addresses</p>
                  </div>
                  <Switch className="data-[state=checked]:bg-neon-green" />
                </div>
                <div className="space-y-2 pt-2">
                  <label className="text-sm font-medium text-foreground">Rotation Interval</label>
                  <select className="w-full bg-muted/30 border border-border/50 rounded-xl px-3 py-2 text-sm text-foreground">
                    <option>Every request</option>
                    <option>Every 5 requests</option>
                    <option>Every 10 requests</option>
                    <option>Every minute</option>
                  </select>
                </div>
              </div>

              <div className="rounded-2xl border border-neon-cyan/30 bg-gradient-to-br from-neon-cyan/5 to-transparent p-5">
                <div className="flex items-center gap-3 mb-3">
                  <Globe className="h-5 w-5 text-neon-cyan" />
                  <p className="font-medium text-foreground">Proxy Pool Status</p>
                </div>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-2xl font-bold text-neon-green">847</p>
                    <p className="text-xs text-muted-foreground">Active</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-warning">23</p>
                    <p className="text-xs text-muted-foreground">Cooldown</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-destructive">5</p>
                    <p className="text-xs text-muted-foreground">Failed</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Appearance Settings */}
          {activeSection === "appearance" && (
            <div className="max-w-2xl space-y-6">
              <div>
                <h2 className="text-xl font-bold text-foreground mb-1">Appearance</h2>
                <p className="text-sm text-muted-foreground">Customize how the dashboard looks</p>
              </div>

              <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5">
                <p className="text-sm font-medium text-foreground mb-4">Theme</p>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { id: "light", icon: Sun, label: "Light" },
                    { id: "dark", icon: Moon, label: "Dark" },
                    { id: "system", icon: Monitor, label: "System" },
                  ].map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setTheme(t.id)}
                      className={cn(
                        "flex flex-col items-center gap-2 p-4 rounded-xl border transition-all",
                        theme === t.id
                          ? "border-neon-cyan bg-neon-cyan/10"
                          : "border-border bg-muted/30 hover:bg-muted"
                      )}
                    >
                      <t.icon className={cn("h-6 w-6", theme === t.id ? "text-neon-cyan" : "text-muted-foreground")} />
                      <span className={cn("text-sm font-medium", theme === t.id ? "text-neon-cyan" : "text-muted-foreground")}>
                        {t.label}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5 space-y-4">
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-foreground">Compact Mode</p>
                    <p className="text-xs text-muted-foreground">Reduce spacing between elements</p>
                  </div>
                  <Switch className="data-[state=checked]:bg-neon-green" />
                </div>
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium text-foreground">Animations</p>
                    <p className="text-xs text-muted-foreground">Enable UI animations</p>
                  </div>
                  <Switch defaultChecked className="data-[state=checked]:bg-neon-green" />
                </div>
              </div>
            </div>
          )}

          {/* Danger Zone */}
          {activeSection === "danger" && (
            <div className="max-w-2xl space-y-6">
              <div>
                <h2 className="text-xl font-bold text-foreground mb-1">Danger Zone</h2>
                <p className="text-sm text-muted-foreground">Irreversible actions</p>
              </div>

              <div className="rounded-2xl border border-destructive/30 bg-gradient-to-br from-destructive/5 to-transparent p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-foreground">Delete All Data</p>
                    <p className="text-xs text-muted-foreground">Remove all scraped data permanently</p>
                  </div>
                  <button className="px-4 py-2 rounded-xl bg-destructive/10 text-destructive font-medium hover:bg-destructive/20 transition-all text-sm">
                    Delete Data
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-foreground">Delete Account</p>
                    <p className="text-xs text-muted-foreground">Permanently delete your account</p>
                  </div>
                  <button className="px-4 py-2 rounded-xl bg-destructive/10 text-destructive font-medium hover:bg-destructive/20 transition-all text-sm">
                    Delete Account
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Default fallback for other sections */}
          {!["account", "notifications", "security", "proxy", "appearance", "danger"].includes(activeSection) && (
            <div className="max-w-2xl">
              <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-8 text-center">
                <div className="h-12 w-12 rounded-xl bg-muted/50 flex items-center justify-center mx-auto mb-4">
                  <HardDrive className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Coming Soon</h3>
                <p className="text-sm text-muted-foreground">
                  This settings section is currently under development.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  )
}
