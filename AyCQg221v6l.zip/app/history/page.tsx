"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import {
  Calendar,
  Download,
  Eye,
  Trash2,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  FileJson,
  FileText,
  Database,
  MoreVertical,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

const historyData = [
  {
    id: 1,
    jobName: "E-commerce Price Monitor",
    date: "2024-01-15",
    time: "14:32:45",
    status: "success",
    items: 2847,
    size: "12.4 MB",
    format: "json",
    duration: "2m 34s",
  },
  {
    id: 2,
    jobName: "Social Media Analytics",
    date: "2024-01-15",
    time: "13:15:22",
    status: "success",
    items: 8432,
    size: "45.2 MB",
    format: "csv",
    duration: "5m 12s",
  },
  {
    id: 3,
    jobName: "News Aggregator",
    date: "2024-01-15",
    time: "12:00:00",
    status: "partial",
    items: 567,
    size: "3.2 MB",
    format: "json",
    duration: "1m 45s",
  },
  {
    id: 4,
    jobName: "Real Estate Listings",
    date: "2024-01-14",
    time: "23:45:12",
    status: "success",
    items: 1234,
    size: "8.7 MB",
    format: "sql",
    duration: "3m 21s",
  },
  {
    id: 5,
    jobName: "Stock Market Data",
    date: "2024-01-14",
    time: "18:30:00",
    status: "failed",
    items: 0,
    size: "0 MB",
    format: "json",
    duration: "0m 45s",
  },
  {
    id: 6,
    jobName: "Job Listings Tracker",
    date: "2024-01-14",
    time: "15:20:33",
    status: "success",
    items: 5621,
    size: "28.9 MB",
    format: "csv",
    duration: "4m 18s",
  },
  {
    id: 7,
    jobName: "Weather Data Collection",
    date: "2024-01-14",
    time: "12:00:00",
    status: "success",
    items: 720,
    size: "2.1 MB",
    format: "json",
    duration: "0m 52s",
  },
  {
    id: 8,
    jobName: "Product Reviews Scraper",
    date: "2024-01-13",
    time: "22:15:00",
    status: "success",
    items: 15234,
    size: "67.3 MB",
    format: "json",
    duration: "8m 45s",
  },
]

const statusConfig = {
  success: { icon: CheckCircle2, color: "text-neon-green", bg: "bg-neon-green/10", label: "Success" },
  failed: { icon: XCircle, color: "text-destructive", bg: "bg-destructive/10", label: "Failed" },
  partial: { icon: Clock, color: "text-warning", bg: "bg-warning/10", label: "Partial" },
}

const formatIcons = {
  json: FileJson,
  csv: FileText,
  sql: Database,
}

export default function HistoryPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedItems, setSelectedItems] = useState<number[]>([])
  const [currentPage, setCurrentPage] = useState(1)

  const toggleSelect = (id: number) => {
    setSelectedItems((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    )
  }

  const toggleSelectAll = () => {
    if (selectedItems.length === historyData.length) {
      setSelectedItems([])
    } else {
      setSelectedItems(historyData.map((h) => h.id))
    }
  }

  const filteredData = historyData.filter((item) =>
    item.jobName.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <DashboardLayout title="History">
      <div className="p-6 space-y-6">
        {/* Stats Overview */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="rounded-xl bg-neon-blue/10 p-2.5">
                <Database className="h-5 w-5 text-neon-blue" />
              </div>
              <span className="text-sm text-muted-foreground">Total Exports</span>
            </div>
            <p className="text-3xl font-bold text-foreground">1,247</p>
          </div>
          <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="rounded-xl bg-neon-green/10 p-2.5">
                <CheckCircle2 className="h-5 w-5 text-neon-green" />
              </div>
              <span className="text-sm text-muted-foreground">Success Rate</span>
            </div>
            <p className="text-3xl font-bold text-foreground">94.8%</p>
          </div>
          <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="rounded-xl bg-neon-cyan/10 p-2.5">
                <FileJson className="h-5 w-5 text-neon-cyan" />
              </div>
              <span className="text-sm text-muted-foreground">Total Data</span>
            </div>
            <p className="text-3xl font-bold text-foreground">2.4 TB</p>
          </div>
          <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="rounded-xl bg-deep-blue/10 p-2.5">
                <Clock className="h-5 w-5 text-deep-blue" />
              </div>
              <span className="text-sm text-muted-foreground">Avg Duration</span>
            </div>
            <p className="text-3xl font-bold text-foreground">3m 24s</p>
          </div>
        </div>

        {/* Search and Actions */}
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search history..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-muted/30 border-border/50 rounded-xl h-11"
            />
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground transition-all text-sm font-medium">
              <Filter className="h-4 w-4" />
              Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground transition-all text-sm font-medium">
              <Calendar className="h-4 w-4" />
              Date Range
            </button>
            {selectedItems.length > 0 && (
              <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-destructive/10 text-destructive hover:bg-destructive/20 transition-all text-sm font-medium">
                <Trash2 className="h-4 w-4" />
                Delete ({selectedItems.length})
              </button>
            )}
          </div>
        </div>

        {/* History Table */}
        <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="px-4 py-4 text-left">
                    <input
                      type="checkbox"
                      checked={selectedItems.length === historyData.length}
                      onChange={toggleSelectAll}
                      className="rounded border-border bg-muted"
                    />
                  </th>
                  <th className="px-4 py-4 text-left text-sm font-medium text-muted-foreground">Job Name</th>
                  <th className="px-4 py-4 text-left text-sm font-medium text-muted-foreground">Date & Time</th>
                  <th className="px-4 py-4 text-left text-sm font-medium text-muted-foreground">Status</th>
                  <th className="px-4 py-4 text-left text-sm font-medium text-muted-foreground">Items</th>
                  <th className="px-4 py-4 text-left text-sm font-medium text-muted-foreground">Size</th>
                  <th className="px-4 py-4 text-left text-sm font-medium text-muted-foreground">Format</th>
                  <th className="px-4 py-4 text-left text-sm font-medium text-muted-foreground">Duration</th>
                  <th className="px-4 py-4 text-left text-sm font-medium text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredData.map((item) => {
                  const status = statusConfig[item.status as keyof typeof statusConfig]
                  const StatusIcon = status.icon
                  const FormatIcon = formatIcons[item.format as keyof typeof formatIcons]

                  return (
                    <tr
                      key={item.id}
                      className={cn(
                        "border-b border-border/50 hover:bg-muted/20 transition-colors",
                        selectedItems.includes(item.id) && "bg-neon-blue/5"
                      )}
                    >
                      <td className="px-4 py-4">
                        <input
                          type="checkbox"
                          checked={selectedItems.includes(item.id)}
                          onChange={() => toggleSelect(item.id)}
                          className="rounded border-border bg-muted"
                        />
                      </td>
                      <td className="px-4 py-4">
                        <span className="font-medium text-foreground">{item.jobName}</span>
                      </td>
                      <td className="px-4 py-4">
                        <div>
                          <p className="text-sm text-foreground">{item.date}</p>
                          <p className="text-xs text-muted-foreground">{item.time}</p>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className={cn("flex items-center gap-1.5 w-fit px-2.5 py-1 rounded-full text-xs font-medium", status.bg, status.color)}>
                          <StatusIcon className="h-3.5 w-3.5" />
                          {status.label}
                        </div>
                      </td>
                      <td className="px-4 py-4 text-sm text-foreground">{item.items.toLocaleString()}</td>
                      <td className="px-4 py-4 text-sm text-foreground">{item.size}</td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                          <FormatIcon className="h-4 w-4" />
                          <span className="uppercase">{item.format}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-sm text-muted-foreground">{item.duration}</td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-1">
                          <button className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
                            <Eye className="h-4 w-4" />
                          </button>
                          <button className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-neon-green">
                            <Download className="h-4 w-4" />
                          </button>
                          <button className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between px-4 py-4 border-t border-border/50">
            <p className="text-sm text-muted-foreground">
              Showing <span className="font-medium text-foreground">1-8</span> of{" "}
              <span className="font-medium text-foreground">1,247</span> results
            </p>
            <div className="flex items-center gap-2">
              <button className="p-2 rounded-lg bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors disabled:opacity-50">
                <ChevronLeft className="h-4 w-4" />
              </button>
              {[1, 2, 3, "...", 156].map((page, i) => (
                <button
                  key={i}
                  className={cn(
                    "px-3 py-1.5 rounded-lg text-sm font-medium transition-colors",
                    page === currentPage
                      ? "bg-gradient-to-r from-neon-blue to-neon-cyan text-background"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  )}
                >
                  {page}
                </button>
              ))}
              <button className="p-2 rounded-lg bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors">
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
