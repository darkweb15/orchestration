"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import {
  Search,
  Play,
  Pause,
  Plus,
  Settings2,
  Globe,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  Filter,
  Download,
  MoreVertical,
  Zap,
  Shield,
  RefreshCw,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

const scraperJobs = [
  {
    id: 1,
    name: "E-commerce Price Monitor",
    url: "amazon.com/products/*",
    status: "running",
    progress: 67,
    items: 1247,
    lastRun: "2 min ago",
    frequency: "Every 6h",
  },
  {
    id: 2,
    name: "Social Media Analytics",
    url: "twitter.com/api/v2/*",
    status: "completed",
    progress: 100,
    items: 8432,
    lastRun: "1 hour ago",
    frequency: "Daily",
  },
  {
    id: 3,
    name: "News Aggregator",
    url: "news.ycombinator.com/*",
    status: "running",
    progress: 34,
    items: 567,
    lastRun: "5 min ago",
    frequency: "Every 1h",
  },
  {
    id: 4,
    name: "Real Estate Listings",
    url: "zillow.com/homes/*",
    status: "paused",
    progress: 45,
    items: 2341,
    lastRun: "3 hours ago",
    frequency: "Every 12h",
  },
  {
    id: 5,
    name: "Stock Market Data",
    url: "finance.yahoo.com/*",
    status: "error",
    progress: 0,
    items: 0,
    lastRun: "Failed",
    frequency: "Every 5m",
  },
  {
    id: 6,
    name: "Job Listings Tracker",
    url: "linkedin.com/jobs/*",
    status: "completed",
    progress: 100,
    items: 5621,
    lastRun: "30 min ago",
    frequency: "Every 4h",
  },
]

const statusConfig = {
  running: {
    icon: Loader2,
    color: "text-neon-cyan",
    bg: "bg-neon-cyan/10",
    label: "Running",
    animate: true,
  },
  completed: {
    icon: CheckCircle2,
    color: "text-neon-green",
    bg: "bg-neon-green/10",
    label: "Completed",
    animate: false,
  },
  paused: {
    icon: Pause,
    color: "text-warning",
    bg: "bg-warning/10",
    label: "Paused",
    animate: false,
  },
  error: {
    icon: XCircle,
    color: "text-destructive",
    bg: "bg-destructive/10",
    label: "Error",
    animate: false,
  },
}

function StatusBadge({ status }: { status: keyof typeof statusConfig }) {
  const config = statusConfig[status]
  const Icon = config.icon

  return (
    <div className={cn("flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium", config.bg, config.color)}>
      <Icon className={cn("h-3.5 w-3.5", config.animate && "animate-spin")} />
      {config.label}
    </div>
  )
}

function JobCard({ job }: { job: (typeof scraperJobs)[0] }) {
  return (
    <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5 transition-all hover:shadow-lg hover:shadow-neon-blue/5 hover:border-neon-blue/30">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-gradient-to-br from-neon-blue/20 to-neon-cyan/10 p-3">
            <Globe className="h-5 w-5 text-neon-cyan" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">{job.name}</h3>
            <p className="text-xs text-muted-foreground font-mono">{job.url}</p>
          </div>
        </div>
        <StatusBadge status={job.status as keyof typeof statusConfig} />
      </div>

      {/* Progress Bar */}
      <div className="mb-4">
        <div className="flex justify-between text-xs mb-1.5">
          <span className="text-muted-foreground">Progress</span>
          <span className="text-foreground font-medium">{job.progress}%</span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div
            className={cn(
              "h-full rounded-full transition-all duration-500",
              job.status === "completed" && "bg-gradient-to-r from-neon-green to-neon-cyan",
              job.status === "running" && "bg-gradient-to-r from-neon-blue to-neon-cyan",
              job.status === "paused" && "bg-warning",
              job.status === "error" && "bg-destructive"
            )}
            style={{ width: `${job.progress}%` }}
          />
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="text-center p-2 rounded-xl bg-muted/30">
          <p className="text-lg font-bold text-foreground">{job.items.toLocaleString()}</p>
          <p className="text-xs text-muted-foreground">Items</p>
        </div>
        <div className="text-center p-2 rounded-xl bg-muted/30">
          <p className="text-sm font-medium text-foreground">{job.lastRun}</p>
          <p className="text-xs text-muted-foreground">Last Run</p>
        </div>
        <div className="text-center p-2 rounded-xl bg-muted/30">
          <p className="text-sm font-medium text-foreground">{job.frequency}</p>
          <p className="text-xs text-muted-foreground">Frequency</p>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-2">
        <button
          className={cn(
            "flex-1 flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-medium transition-all",
            job.status === "running"
              ? "bg-warning/10 text-warning hover:bg-warning/20"
              : "bg-neon-green/10 text-neon-green hover:bg-neon-green/20"
          )}
        >
          {job.status === "running" ? (
            <>
              <Pause className="h-4 w-4" /> Pause
            </>
          ) : (
            <>
              <Play className="h-4 w-4" /> Start
            </>
          )}
        </button>
        <button className="flex items-center justify-center rounded-xl px-3 py-2.5 bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground transition-all">
          <Settings2 className="h-4 w-4" />
        </button>
        <button className="flex items-center justify-center rounded-xl px-3 py-2.5 bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground transition-all">
          <MoreVertical className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filter, setFilter] = useState("all")

  const filteredJobs = scraperJobs.filter((job) => {
    if (filter !== "all" && job.status !== filter) return false
    if (searchQuery && !job.name.toLowerCase().includes(searchQuery.toLowerCase())) return false
    return true
  })

  return (
    <DashboardLayout title="Scraper Jobs">
      <div className="p-6 space-y-6">
        {/* Quick Stats */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-2xl border border-neon-blue/30 bg-gradient-to-br from-neon-blue/10 to-transparent p-4 flex items-center gap-4">
            <div className="rounded-xl bg-neon-blue/20 p-3">
              <Zap className="h-5 w-5 text-neon-blue" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">23</p>
              <p className="text-xs text-muted-foreground">Active Scrapers</p>
            </div>
          </div>
          <div className="rounded-2xl border border-neon-green/30 bg-gradient-to-br from-neon-green/10 to-transparent p-4 flex items-center gap-4">
            <div className="rounded-xl bg-neon-green/20 p-3">
              <CheckCircle2 className="h-5 w-5 text-neon-green" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">156</p>
              <p className="text-xs text-muted-foreground">Completed Today</p>
            </div>
          </div>
          <div className="rounded-2xl border border-neon-cyan/30 bg-gradient-to-br from-neon-cyan/10 to-transparent p-4 flex items-center gap-4">
            <div className="rounded-xl bg-neon-cyan/20 p-3">
              <Shield className="h-5 w-5 text-neon-cyan" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">847</p>
              <p className="text-xs text-muted-foreground">Proxies Active</p>
            </div>
          </div>
          <div className="rounded-2xl border border-deep-blue/30 bg-gradient-to-br from-deep-blue/10 to-transparent p-4 flex items-center gap-4">
            <div className="rounded-xl bg-deep-blue/20 p-3">
              <RefreshCw className="h-5 w-5 text-deep-blue" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">1.2M</p>
              <p className="text-xs text-muted-foreground">Total Requests</p>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search scraper jobs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-muted/30 border-border/50 rounded-xl h-11"
            />
          </div>
          <div className="flex gap-2">
            {["all", "running", "completed", "paused", "error"].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={cn(
                  "px-4 py-2.5 rounded-xl text-sm font-medium transition-all capitalize",
                  filter === f
                    ? "bg-gradient-to-r from-neon-blue to-neon-cyan text-background"
                    : "bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
              >
                {f}
              </button>
            ))}
          </div>
          <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-neon-green to-neon-cyan text-background font-medium transition-all hover:opacity-90">
            <Plus className="h-4 w-4" />
            New Scraper
          </button>
        </div>

        {/* Jobs Grid */}
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filteredJobs.map((job) => (
            <JobCard key={job.id} job={job} />
          ))}
        </div>

        {filteredJobs.length === 0 && (
          <div className="text-center py-12">
            <div className="rounded-2xl bg-muted/30 p-8 max-w-md mx-auto">
              <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">No scrapers found</h3>
              <p className="text-sm text-muted-foreground">
                Try adjusting your search or filter to find what you&apos;re looking for.
              </p>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
